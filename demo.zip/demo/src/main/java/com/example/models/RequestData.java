package com.example.models;

public class RequestData {

    private RequestPayload requestPayload;

    public RequestData() {
    }

    public RequestData(RequestPayload requestPayload) {
	super();
	this.requestPayload = requestPayload;
    }

    public RequestPayload getRequestPayload() {
	return requestPayload;
    }

    public void setRequestPayload(RequestPayload requestPayload) {
	this.requestPayload = requestPayload;
    }

}
