package com.example.service;

import java.util.Optional;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.springframework.stereotype.Service;

import com.example.beans.Customer;
import com.example.dao.CustomerRepository;

@Service
public class CustomerService {
	
	   private final CustomerRepository customerRepository;
	    public CustomerService(CustomerRepository customerRepository) {
	        this.customerRepository = customerRepository;
	    }
	    
	    @Transactional(value = TxType.REQUIRED)
	    public boolean addCustomer(Customer customer) {
	    	Customer customerAdded = customerRepository.save(customer);
	    	return customerAdded.getCid()!=null;
	    }
	   
	    @Transactional(value = TxType.REQUIRED)
	    public boolean saveOrModifyCustomer(Customer customer) {
	    	try {
	        Optional<Customer> customerOp = customerRepository.findById(customer.getAccId());
	        customerOp.ifPresentOrElse(c -> {
				c.setCustomerFname(customer.getCustomerFname());
				c.setCustomerMname(customer.getCustomerMname());
				c.setCustomerLname(customer.getCustomerLname());
	        }, ()-> customerRepository.save(customer));
	    	}catch (Exception e) {
				return false;
			}
			return true;
	    }
}
