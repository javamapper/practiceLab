package com.example.util;

public class Constant {
    public static final String SUCCESS = "Operation completed successfully";
    public static final String FAILED = "Operation Failed";
    public static final String FAILED_INTERNAL = "Internal server issue";
}
