package com.example.beans;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customer")
public class Customer implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String cid;
	@Id	
	private String accId;
	private String customerFname;
	private String customerMname;
	private String customerLname;
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getAccId() {
		return accId;
	}
	public void setAccId(String accId) {
		this.accId = accId;
	}
	public String getCustomerFname() {
		return customerFname;
	}
	public void setCustomerFname(String customerFname) {
		this.customerFname = customerFname;
	}
	public String getCustomerMname() {
		return customerMname;
	}
	public void setCustomerMname(String customerMname) {
		this.customerMname = customerMname;
	}
	public String getCustomerLname() {
		return customerLname;
	}
	public void setCustomerLname(String customerLname) {
		this.customerLname = customerLname;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accId == null) ? 0 : accId.hashCode());
		result = prime * result + ((cid == null) ? 0 : cid.hashCode());
		result = prime * result + ((customerFname == null) ? 0 : customerFname.hashCode());
		result = prime * result + ((customerLname == null) ? 0 : customerLname.hashCode());
		result = prime * result + ((customerMname == null) ? 0 : customerMname.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (accId == null) {
			if (other.accId != null)
				return false;
		} else if (!accId.equals(other.accId))
			return false;
		if (cid == null) {
			if (other.cid != null)
				return false;
		} else if (!cid.equals(other.cid))
			return false;
		if (customerFname == null) {
			if (other.customerFname != null)
				return false;
		} else if (!customerFname.equals(other.customerFname))
			return false;
		if (customerLname == null) {
			if (other.customerLname != null)
				return false;
		} else if (!customerLname.equals(other.customerLname))
			return false;
		if (customerMname == null) {
			if (other.customerMname != null)
				return false;
		} else if (!customerMname.equals(other.customerMname))
			return false;
		return true;
	}
	
	
}
